var n1 ;
var n2 ;
var n3 ;
var n4 ;

n1 = prompt('Digite um número');
n2 = prompt('Digite outro número');
n3 = prompt('Digite mais um número');
n4 = prompt('Digite o ultimo número');

function soma(n1, n2, n3, n4) {
    
return n1 *1 + n2 *1 + n3 *1 + n4 * 1

}

alert(`A soma desses numeros é ${soma(n1, n2, n3, n4)}`)


alert(`E a média é ${soma(n1, n2, n3, n4) / 4}`)