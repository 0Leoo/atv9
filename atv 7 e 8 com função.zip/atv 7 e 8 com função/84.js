var quan;
var num1;
var num2;
var num3;
var num4;
var num5;
var num6;
var num7;
var num8;
var num9;
var num10;


quan = prompt('Digite a quatidade de números quer somar (0 a 10');

alert("Agora informe quais são esses números(digite apenas a quatidade de números que escolheu, se passar dessa quatidade apenas pressione -ok- ")

num1 = prompt(" primeiro número")

num2 = prompt(" segundo número")

num3 = prompt(" terceiro número")

num4 = prompt(" quarto número")

num5 = prompt(" quinto número")

num6 = prompt(" sexto número")

num7 = prompt(" setimo número")

num8 = prompt(" oitavo número")

num9 = prompt(" nono número")

num10 = prompt(" decimo número")

function soma(num1, num2, num3, num4, num5, num6, num7, num8, num9, num10) {
    
return num1 *1 + num2 *1 + num3 *1 + num4 *1 + num5 *1 + num6 *1 + num7 *1 + num8 *1 + num9 *1 + num10 * 1

}

alert(`A soma desses numeros é ${soma(num1, num2, num3, num4, num5, num6, num7, num8, num9, num10)}`)

alert(`E a média é ${soma(num1, num2, num3, num4, num5, num6, num7, num8, num9, num10) / quan}`)



