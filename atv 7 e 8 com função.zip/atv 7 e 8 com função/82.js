var num1 ;
var num2 ;
var caractere ;

alert("Olá novamente, esta é a cauculadora :)");
num1 = prompt("Digite um número inteiro")
num2 = prompt("Digite outro número inteiro")
caractere = prompt("Agora digite um caractere (+,-,* ou /)")

function soma(num1, num2) {
    
return num1 * 1 +  num2 * 1

}

function subtração(num1, num2) {
    
    return num1  -  num2 
    
}

function multiplicação(num1, num2) {
    
    return num1  *  num2 
    
}

function divisão(num1, num2) {
    
    return num1  /  num2 
    
}


if (caractere == "+"){
    alert(`O resultado é ${soma(num1, num2)}`);

}

else if (caractere == "-"){
    alert(`O resultado é ${subtração(num1, num2)}`);

}

else if (caractere == "*"){
    alert(`O resultado é ${multiplicação(num1, num2)}`);

}

else if (caractere == "/"){
    alert(`O resultado é ${divisão(num1, num2)}`);

}

else {
    alert(`O cauculo e Inválido`);

}