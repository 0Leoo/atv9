alert('Olá,  por favor responda as seguintes perguntas');

var seu_nome;
var ano_nascimento;
var ano_atual

seu_nome = prompt('Olá, qual seu nome?')

ano_atual = prompt('Podereia me informar em que ano estamos?');

ano_nascimento = prompt ('Em que ano você nasceu?');

function sua_idade(ano_atual, ano_nascimento){

return ano_atual - ano_nascimento

}

alert(`De acordo com essas informações  ${seu_nome}, você tem  ${sua_idade(ano_atual, ano_nascimento)} ano de idade.`)

