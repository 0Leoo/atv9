var num1 ;
var num2;


num1 = prompt('Digite um número par inteiro');
num2 = prompt('Digite um número inteiro que sejá maior que o anterior');


function soma(num1, num2) {

    while (num1 >= num2) {
    

        soma(num1)++
        
        }
    return 1 + num1++ 

}


alert (`Os impares sao ${soma(num1, num2)} `)
    
