var saldo = parseInt 
var preço = parseInt 

alert ('Olá, bem vindo(a) ou Sistema Bacário :)');
saldo = prompt('Por favor digite o seu saldo:');
preço = prompt('Agora o preço da compra que deseja realizar:');
 

function compra(saldo, preço) {
    

    return saldo - preço
    
    }
    
    if (saldo <= preço) {
    
        alert(`Compra realizada com sucesso, agora você possui o saldo de R$${compra(saldo, preço)} reais`)
    }
    
    
       else if (saldo > preço) {
        
            alert(`Saldo insulficiênte`)
        }
