
var x;
var y;

alert("Bem vindo(a) a calculadora de potenciação :)");

x = prompt("Digite um número (inteiro)");
y = prompt("Agora digite um expoente para o número (inteiro)");

Math.pow (x, y)

alert(`O resultado é ${Math.pow (x, y)}!`)