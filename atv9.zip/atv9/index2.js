
var x;
var y;

alert("Bem vindo(a) a calculadora de potenciação :)");

x = prompt("Digite um número (inteiro)");
y = prompt("Agora digite um expoente para o número (inteiro)");

function calculo( x, y) {
    return x ** y
}

alert(`O resultado é ${calculo(x, y)}!`);