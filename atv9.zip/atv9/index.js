
var a;
var b;

alert("Bem vindo(a) a calculadora de multiplicação :)");

a = prompt("Digite o primeiro número (inteiro)");
b = prompt("Agora digite o segundo número (inteiro)");

function calculo(a, b) {
    
return a * b;
}

alert(`O resultado é ${calculo(a, b)}!`);